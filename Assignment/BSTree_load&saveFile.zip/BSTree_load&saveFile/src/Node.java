public class Node {
   Employee info;
   Node left,right;
   Node() {
   }
   Node(Employee x) {
     info=x;
     left=right=null;
   }
}
